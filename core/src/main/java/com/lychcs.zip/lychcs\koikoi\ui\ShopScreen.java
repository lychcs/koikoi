package com.lychcs.koikoi.ui;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.ScreenAdapter;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.Pixmap;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.NinePatch;
import com.badlogic.gdx.graphics.g2d.TextureAtlas;
import com.badlogic.gdx.graphics.g2d.TextureRegion;
import com.badlogic.gdx.math.Interpolation;
import com.badlogic.gdx.scenes.scene2d.Actor;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.actions.Actions;
import com.badlogic.gdx.scenes.scene2d.ui.*;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.scenes.scene2d.utils.NinePatchDrawable;
import com.badlogic.gdx.scenes.scene2d.utils.TextureRegionDrawable;
import com.badlogic.gdx.utils.Align;
import com.badlogic.gdx.utils.ScreenUtils;
import com.badlogic.gdx.utils.viewport.FitViewport;
import com.lychcs.koikoi.KoiKoiGame;
import com.lychcs.koikoi.graphics.FontManager;
import com.lychcs.koikoi.model.Card;
import com.lychcs.koikoi.model.Deck;
import com.lychcs.koikoi.model.hanko.HankoEffect;
import com.lychcs.koikoi.model.omamori.Omamori;
import com.lychcs.koikoi.model.omamori.OmamoriPool;
import com.lychcs.koikoi.run.RunSession;

import static com.lychcs.koikoi.graphics.FontManager.COLOR_TEXT_MAIN;

public class ShopScreen extends ScreenAdapter {
    private final Stage stage;
    private final RunSession runSession;
    private Skin skin;
    private TextureAtlas atlas;

    private Texture background;
    private Texture boosterPackTexture;
    private Texture panelTex;
    private Texture buttonTex;
    private NinePatchDrawable panelBackground;
    private TextButton.TextButtonStyle indieButtonStyle;

    private Label monLabel;
    private Table boosterOverlay;

    private Texture darkOverlayTex;
    private TextureRegionDrawable darkOverlayBackground;

    public ShopScreen(RunSession runSession) {
        this.runSession = runSession;
        this.stage = new Stage(new FitViewport(1280, 720));

        initAssets();

        buildShopUi();

        Gdx.input.setInputProcessor(stage);
    }

    private void initAssets() {
        skin = new Skin(Gdx.files.internal("uiskin.json"));
        skin.add("default-font", FontManager.getFont(), BitmapFont.class);
        skin.get(Label.LabelStyle.class).font = FontManager.getFont();

        atlas = new TextureAtlas(Gdx.files.internal("packed/game_assets.atlas"));
        for (Texture tex : atlas.getTextures()) {
            tex.setFilter(Texture.TextureFilter.Nearest, Texture.TextureFilter.Nearest);
        }

        background = new Texture(Gdx.files.internal(getSeasonalBackgroundPath("SHOP")));

        boosterPackTexture = new Texture(Gdx.files.internal("backgrounds/BOOSTER_PACK.png"));
        boosterPackTexture.setFilter(Texture.TextureFilter.Nearest, Texture.TextureFilter.Nearest);

        // VRAM Fix: Referenz auf die Texture speichern, um sie im dispose() zu vernichten
        panelTex = new Texture(Gdx.files.internal("backgrounds/PANEL_PLAYING_BOARD.9.png"));
        panelBackground = new NinePatchDrawable(new NinePatch(panelTex, 20, 20, 20, 20));

        buttonTex = new Texture(Gdx.files.internal("backgrounds/BUTTONS_PLAYING_BOARD.9.png"));
        indieButtonStyle = new TextButton.TextButtonStyle();
        indieButtonStyle.up = new NinePatchDrawable(new NinePatch(buttonTex, 15, 15, 15, 15));
        indieButtonStyle.down = ((NinePatchDrawable) indieButtonStyle.up).tint(Color.LIGHT_GRAY);
        indieButtonStyle.font = FontManager.getFont();
        indieButtonStyle.fontColor = COLOR_TEXT_MAIN;

        Pixmap pixmap = new Pixmap(1, 1, Pixmap.Format.RGBA8888);
        pixmap.setColor(new Color(0, 0, 0, 0.85f));
        pixmap.fill();
        darkOverlayTex = new Texture(pixmap);
        darkOverlayBackground = new TextureRegionDrawable(new TextureRegion(darkOverlayTex));
        pixmap.dispose();
    }

    private void buildShopUi() {
        Table root = new Table();
        root.setFillParent(true);

        Table shelves = new Table();
        shelves.padTop(80).padBottom(120).padLeft(120).padRight(120);
        shelves.setFillParent(true);

        Table column1 = new Table(); // Omamoris
        Table column2 = new Table(); // Booster Packs
        Table column3 = new Table(); // Upgrades (ehemals Fukus)

        // ==========================================
        // SPALTE 1: RANDOM OMAMORIS AUS DEM POOL
        // ==========================================
        Omamori oma1 = OmamoriPool.getRandomOmamori();
        Omamori oma2 = OmamoriPool.getRandomOmamori();

        while (oma2.getClass().equals(oma1.getClass())) {
            oma2 = OmamoriPool.getRandomOmamori();
        }

        column1.add(createOmamoriCard(oma1)).padBottom(20).row();
        column1.add(createOmamoriCard(oma2)).row();

        // ==========================================
        // BOTTOM BAR & REFRESH LOGIK
        // ==========================================

        Table bottomBar = new Table();
        bottomBar.setFillParent(true);
        bottomBar.bottom().padBottom(35);

        TextButton refreshButton = new TextButton("Refresh (-10)", indieButtonStyle);
        refreshButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                if (runSession.getMon() >= 10) {
                    runSession.addMon(-10);
                    stage.clear();
                    buildShopUi();
                }
            }
        });

        monLabel = new Label(String.valueOf(runSession.getMon()), skin);
        monLabel.setFontScale(2f);
        monLabel.setColor(Color.WHITE);
        monLabel.setAlignment(Align.center);

        TextButton exitButton = new TextButton("Leave Market", indieButtonStyle);
        exitButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                ((KoiKoiGame) Gdx.app.getApplicationListener()).setScreen(new OverworldScreen(runSession));
            }
        });

        bottomBar.add(refreshButton).width(200).height(60).padLeft(80);
        bottomBar.add(monLabel).expandX().center();
        bottomBar.add(exitButton).width(200).height(60).padRight(80);

        stage.addActor(bottomBar);
    }

    private String getSeasonalBackgroundPath(String prefix) {
        String seasonName = runSession.getCurrentSeason().name();
        return "backgrounds/" + "BACKGROUND" + "_" + prefix + "_" + seasonName + ".jpg";
    }

    private Table createOmamoriCard(Omamori omamori) {
        Table card = new Table();
        card.setBackground(panelBackground);

        String className = omamori.getClass().getSimpleName();
        String snakeCaseName = className.replaceAll("([a-z])([A-Z]+)", "$1_$2").toUpperCase();
        String regionName = "OMAMORI_" + snakeCaseName;

        TextureRegion region = atlas.findRegion(regionName);
        Actor icon = (region != null) ? new Image(region) : new Label("No Img", skin);

        Label nameLabel = new Label(omamori.getName(), skin);
        nameLabel.setFontScale(0.9f);
        Label descLabel = new Label(omamori.getDescription(), skin);
        descLabel.setWrap(true);
        descLabel.setAlignment(Align.center);
        descLabel.setFontScale(0.8f);

        int price = OmamoriPool.getCost(omamori.getRarity());
        TextButton buyButton = new TextButton(price + " Mon", indieButtonStyle);

        buyButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                if (runSession.getMon() >= price) {
                    runSession.addMon(-price);
                    runSession.getActiveOmamoris().add(omamori);
                    updateMonDisplay();

                    card.clearChildren();
                    Label soldOut = new Label("SOLD OUT", skin);
                    soldOut.setColor(Color.FIREBRICK);
                    card.add(soldOut).expand().center();
                }
            }
        });

        card.add(nameLabel).padTop(10).padBottom(5).row();
        card.add(icon).width(72).height(96).row();
        card.add(descLabel).expand().fill().pad(5).row();
        card.add(buyButton).width(160).height(45).padBottom(10);

        return card;
    }

    /**
     * Zieht nun automatisch das Mon ab und setzt das Item auf "SOLD OUT".
     */
    private Table createItemCard(String name, String desc, int price, Runnable onBuyEffect) {
        Table card = new Table();
        card.setBackground(panelBackground);

        Label nameLabel = new Label(name, skin);
        Label descLabel = new Label(desc, skin);
        descLabel.setWrap(true);
        descLabel.setAlignment(Align.center);

        TextButton buyButton = new TextButton(price + " Mon", indieButtonStyle);
        buyButton.addListener(new ClickListener() {
            @Override
            public void clicked(InputEvent event, float x, float y) {
                if (runSession.getMon() >= price) {
                    runSession.addMon(-price);
                    updateMonDisplay();

                    onBuyEffect.run();

                    card.clearChildren();
                    Label soldOut = new Label("SOLD OUT", skin);
                    soldOut.setColor(Color.FIREBRICK);
                    card.add(soldOut).expand().center();
                }
            }
        });

        card.add(nameLabel).padTop(15).padBottom(5).row();
        card.add(descLabel).expand().fill().pad(5).row();
        card.add(buyButton).width(160).height(50).padBottom(15);

        return card;
    }

    private void updateMonDisplay() {
        monLabel.setText(String.valueOf(runSession.getMon()));
    }

    @Override
    public void render(float delta) {
        ScreenUtils.clear(0f, 0f, 0f, 1f);

        stage.getBatch().begin();
        stage.getBatch().draw(background, 0, 0, 1280, 720);
        stage.getBatch().end();

        stage.act(delta);
        stage.draw();
    }

    @Override
    public void show() {
        Gdx.input.setInputProcessor(stage);
    }

    @Override
    public void dispose() {
        stage.dispose();
        if (background != null) background.dispose();
        if (boosterPackTexture != null) boosterPackTexture.dispose();
        if (atlas != null) atlas.dispose();
        if (darkOverlayTex != null) darkOverlayTex.dispose();
        if (panelTex != null) panelTex.dispose();
        if (buttonTex != null) buttonTex.dispose();
    }
}
